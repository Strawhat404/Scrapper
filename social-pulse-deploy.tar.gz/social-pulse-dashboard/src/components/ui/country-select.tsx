import { useState, useRef, useEffect } from "react";
import { Check, ChevronDown, X } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { filterCountries } from "@/lib/countries";

interface CountrySelectProps {
  value: string[];
  onChange: (countries: string[]) => void;
  placeholder?: string;
  multiple?: boolean;
  className?: string;
}

export function CountrySelect({ 
  value, 
  onChange, 
  placeholder = "Select countries...", 
  multiple = true,
  className 
}: CountrySelectProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredCountries, setFilteredCountries] = useState<string[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setFilteredCountries(filterCountries(searchQuery));
  }, [searchQuery]);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSearchQuery("");
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const handleCountrySelect = (country: string) => {
    if (multiple) {
      if (value.includes(country)) {
        onChange(value.filter(c => c !== country));
      } else {
        onChange([...value, country]);
      }
    } else {
      onChange([country]);
      setIsOpen(false);
      setSearchQuery("");
    }
  };

  const handleRemoveCountry = (country: string) => {
    onChange(value.filter(c => c !== country));
  };

  const handleClearAll = () => {
    onChange([]);
  };

  return (
    <div ref={containerRef} className={cn("relative", className)}>
      <div
        className={cn(
          "min-h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm cursor-pointer",
          "focus-within:ring-2 focus-within:ring-ring focus-within:ring-offset-2",
          isOpen && "ring-2 ring-ring ring-offset-2"
        )}
        onClick={() => setIsOpen(!isOpen)}
      >
        <div className="flex flex-wrap gap-1 items-center">
          {value.length > 0 ? (
            <>
              {value.map((country) => (
                <Badge
                  key={country}
                  variant="secondary"
                  className="bg-blue-50 text-blue-600 hover:bg-blue-100"
                >
                  {country}
                  {multiple && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleRemoveCountry(country);
                      }}
                      className="ml-1 hover:text-blue-800"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  )}
                </Badge>
              ))}
              {multiple && value.length > 0 && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    handleClearAll();
                  }}
                  className="h-6 px-2 text-xs text-muted-foreground hover:text-foreground"
                >
                  Clear all
                </Button>
              )}
            </>
          ) : (
            <span className="text-muted-foreground">{placeholder}</span>
          )}
          <ChevronDown className={cn("h-4 w-4 ml-auto transition-transform", isOpen && "rotate-180")} />
        </div>
      </div>

      {isOpen && (
        <div className="absolute z-50 w-full mt-1 bg-popover border rounded-md shadow-md max-h-60 overflow-hidden">
          <div className="p-2 border-b">
            <Input
              placeholder="Search countries..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="h-8"
              autoFocus
            />
          </div>
          <div className="max-h-48 overflow-y-auto">
            {filteredCountries.length === 0 ? (
              <div className="p-2 text-sm text-muted-foreground text-center">
                No countries found
              </div>
            ) : (
              filteredCountries.map((country) => (
                <div
                  key={country}
                  className={cn(
                    "flex items-center justify-between px-2 py-1.5 text-sm cursor-pointer hover:bg-blue-50",
                    value.includes(country) && "bg-blue-50"
                  )}
                  onClick={() => handleCountrySelect(country)}
                >
                  <span>{country}</span>
                  {value.includes(country) && (
                    <Check className="h-4 w-4 text-primary" />
                  )}
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}