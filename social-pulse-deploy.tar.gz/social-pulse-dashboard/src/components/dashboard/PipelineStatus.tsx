import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { Activity, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { getPipelineStats } from "@/lib/api";

interface PipelineJob {
  id: string;
  type: string;
  status: "running" | "completed" | "queued" | "failed";
  platform: string;
  timestamp: string;
  progress?: number;
}

export function PipelineStatus() {
  const [jobs, setJobs] = useState<PipelineJob[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadJobs();
    
    // Auto-refresh every 15 seconds
    const interval = setInterval(loadJobs, 15000);
    return () => clearInterval(interval);
  }, []);

  async function loadJobs() {
    try {
      const pipelineData = await getPipelineStats();
      setJobs(pipelineData.jobs.map(job => ({
        id: job.id,
        type: job.type,
        status: job.status,
        platform: job.platform,
        timestamp: job.timestamp,
        progress: job.progress
      })));
    } catch (error) {
      console.error('Error loading pipeline jobs:', error);
      // Show empty state instead of mock data
      setJobs([]);
    } finally {
      setLoading(false);
    }
  }

  const runningCount = jobs.filter(job => job.status === "running").length;
  const queuedCount = jobs.filter(job => job.status === "queued").length;

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg font-semibold">
          <Activity className="h-5 w-5 text-primary" />
          Pipeline Status & Job Queue
        </CardTitle>
        <div className="flex gap-6 text-sm">
          <span className="text-muted-foreground">Running: <span className="font-medium text-blue-600">{runningCount}</span></span>
          <span className="text-muted-foreground">Queued: <span className="font-medium text-yellow-600">{queuedCount}</span></span>
          <span className="text-muted-foreground">Total Jobs: <span className="font-medium">{jobs.length}</span></span>
        </div>
      </CardHeader>
      <CardContent className="space-y-3">
        {loading ? (
          <div className="text-center py-8 text-muted-foreground">Loading pipeline status...</div>
        ) : jobs.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg font-medium mb-2">No Active Jobs</p>
            <p className="text-sm">Pipeline is currently idle. Jobs will appear here when scraping is active.</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {jobs.map((job) => (
              <div 
                key={job.id}
                className="flex items-center gap-4 rounded-lg border border-border p-4 hover:bg-muted/30 transition-colors"
              >
                <div className={cn(
                  "flex h-8 w-8 items-center justify-center rounded-full",
                  job.status === "running" && "bg-blue-100 text-blue-600",
                  job.status === "completed" && "bg-green-100 text-green-600",
                  job.status === "queued" && "bg-yellow-100 text-yellow-600",
                  job.status === "failed" && "bg-red-100 text-red-600"
                )}>
                  {job.status === "running" && <Activity className="h-4 w-4" />}
                  {job.status === "completed" && <CheckCircle2 className="h-4 w-4" />}
                  {job.status === "queued" && <Clock className="h-4 w-4" />}
                  {job.status === "failed" && <AlertCircle className="h-4 w-4" />}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-base font-medium text-foreground">{job.platform}</span>
                    <span className="text-sm text-muted-foreground">{job.timestamp}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-sm text-muted-foreground">{job.type}</span>
                    <span className={cn(
                      "text-xs px-2 py-1 rounded-full font-medium",
                      job.status === "running" && "bg-blue-100 text-blue-700",
                      job.status === "completed" && "bg-green-100 text-green-700",
                      job.status === "queued" && "bg-yellow-100 text-yellow-700",
                      job.status === "failed" && "bg-red-100 text-red-700"
                    )}>
                      {job.status.charAt(0).toUpperCase() + job.status.slice(1)}
                    </span>
                    {job.progress !== undefined && job.status === "running" && (
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 bg-gray-200 rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-blue-500 transition-all duration-300"
                            style={{ width: `${job.progress}%` }}
                          />
                        </div>
                        <span className="text-xs text-muted-foreground font-medium">
                          {job.progress}%
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
