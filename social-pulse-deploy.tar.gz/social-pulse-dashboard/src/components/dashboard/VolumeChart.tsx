import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { calculateDateRangeTitle } from "@/lib/date-utils";

// Define the shape of data this component expects
interface VolumeChartProps {
  data: Array<{ date: string; posts: number }>;
  startDate?: Date;
  endDate?: Date;
  totalDataDays?: number;
  countries?: string[];
}

export function VolumeChart({ data, startDate, endDate, totalDataDays, countries }: VolumeChartProps) {
  // Format dates for display (e.g., "2024-12-24" -> "Dec 24")
  const formattedData = data.map(item => ({
    name: new Date(item.date).toLocaleDateString('en-US', { 
      month: 'short',  // "Dec" instead of "December"
      day: 'numeric'   // "24" instead of "24th"
    }),
    posts: item.posts,
  }));

  // Calculate dynamic title based on date range
  const chartTitle = calculateDateRangeTitle(startDate, endDate, totalDataDays);

  // Add country filter info to title if countries are selected
  const titleWithCountries = countries && countries.length > 0 
    ? `${chartTitle} - ${countries.length === 1 ? countries[0] : `${countries.length} Countries`}`
    : chartTitle;

  return (
    <Card className="col-span-2">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg font-semibold">
          {titleWithCountries}
        </CardTitle>
        {countries && countries.length > 1 && (
          <p className="text-sm text-muted-foreground">
            Filtered by: {countries.slice(0, 3).join(', ')}{countries.length > 3 ? ` and ${countries.length - 3} more` : ''}
          </p>
        )}
      </CardHeader>
      <CardContent className="pt-4">
        <div className="h-[300px] w-full">
          {/* Show message if no data available */}
          {formattedData.length === 0 ? (
            <div className="flex h-full items-center justify-center text-muted-foreground">
              No data available yet. Start scraping to see volume trends!
            </div>
          ) : (
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={formattedData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" vertical={false} />
                <XAxis 
                  dataKey="name" 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <YAxis 
                  stroke="hsl(var(--muted-foreground))" 
                  fontSize={12}
                  tickLine={false}
                  axisLine={false}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "8px"
                  }}
                />
                <Bar 
                  dataKey="posts" 
                  fill="hsl(var(--primary))" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
