import { RefreshCcw, Plus } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";

export function Header() {
  const navigate = useNavigate();

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-border bg-background/95 px-6 backdrop-blur-sm shadow-sm">
      <div className="flex items-center gap-4">
        <div>
          <h1 className="text-xl font-semibold text-foreground tracking-tight">Dashboard</h1>
          <p className="text-sm text-muted-foreground">Social media intelligence platform</p>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Button 
          variant="outline" 
          size="sm" 
          className="h-9 gap-2 font-medium"
          onClick={() => window.location.reload()}
        >
          <RefreshCcw className="h-4 w-4" />
          <span className="hidden sm:inline">Refresh</span>
        </Button>
        <Button 
          variant="default" 
          size="sm" 
          className="h-9 gap-2 font-medium shadow-sm"
          onClick={() => navigate("/discovery")}
        >
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">New Analysis</span>
        </Button>
      </div>
    </header>
  );
}
