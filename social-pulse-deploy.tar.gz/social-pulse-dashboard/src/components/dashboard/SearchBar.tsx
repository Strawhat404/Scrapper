import { useState } from "react";
import { Calendar, X, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { CountrySelect } from "@/components/ui/country-select";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface SearchBarProps {
  startDate?: Date;
  endDate?: Date;
  countries?: string[];
  onStartDateChange?: (date: Date | undefined) => void;
  onEndDateChange?: (date: Date | undefined) => void;
  onCountriesChange?: (countries: string[]) => void;
  onClear?: () => void;
}

export function SearchBar({
  startDate,
  endDate,
  countries = [],
  onStartDateChange,
  onEndDateChange,
  onCountriesChange,
  onClear
}: SearchBarProps) {
  const [clearDialogOpen, setClearDialogOpen] = useState(false);

  const handleClearClick = () => {
    setClearDialogOpen(true);
  };

  const handleClearConfirm = () => {
    onStartDateChange?.(undefined);
    onEndDateChange?.(undefined);
    onCountriesChange?.([]);
    onClear?.();
    setClearDialogOpen(false);
  };

  const hasFilters = startDate || endDate || countries.length > 0;

  return (
    <div className="flex gap-4 items-center bg-white p-4 rounded-lg border">
      {/* Start Date */}
      <div className="flex flex-col gap-1 flex-1">
        <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
          <Calendar className="h-3 w-3" />
          Start Date
        </label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className="w-full justify-start text-left font-normal h-9"
            >
              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
              {startDate ? format(startDate, "MMM dd, yyyy") : "Select date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <CalendarComponent
              mode="single"
              selected={startDate}
              onSelect={onStartDateChange}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      {/* End Date */}
      <div className="flex flex-col gap-1 flex-1">
        <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
          <Calendar className="h-3 w-3" />
          End Date
        </label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className="w-full justify-start text-left font-normal h-9"
            >
              <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
              {endDate ? format(endDate, "MMM dd, yyyy") : "Select date"}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <CalendarComponent
              mode="single"
              selected={endDate}
              onSelect={onEndDateChange}
              initialFocus
            />
          </PopoverContent>
        </Popover>
      </div>

      {/* Target Countries */}
      <div className="flex flex-col gap-1 flex-1">
        <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
          <Globe className="h-3 w-3" />
          Target Countries
        </label>
        <CountrySelect
          value={countries}
          onChange={onCountriesChange || (() => {})}
          placeholder="Select countries..."
          multiple={true}
        />
      </div>

      {/* Clear Data Button */}
      {hasFilters && (
        <Button 
          variant="ghost" 
          size="sm" 
          onClick={handleClearClick}
          className="text-red-500 hover:text-red-600 hover:bg-red-50 h-9 mt-5 flex-shrink-0"
        >
          <X className="mr-1 h-4 w-4" />
          Clear Data
        </Button>
      )}

      {/* Clear Data Confirmation Dialog */}
      <Dialog open={clearDialogOpen} onOpenChange={setClearDialogOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Are you sure?</DialogTitle>
            <DialogDescription>
              This action will clear all filters and reset the view to show all data.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="flex gap-2 sm:gap-2">
            <Button variant="outline" onClick={() => setClearDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleClearConfirm}>
              Clear Filters
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}