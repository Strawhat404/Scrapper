import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ExternalLink, Search, Download, X, Trash2 } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";

interface ContentItem {
  id: string;
  platform: string;
  author: string;
  content: string;
  timestamp: string;
  type: string;
  engagement: string;
  postUrl?: string; // Add optional postUrl field
}

interface ContentFeedProps {
  posts?: Array<{
    id: string;
    platform: string;
    authorUsername: string;
    content: string;
    createdAt: string;
    postUrl: string;
    likes?: number;      // Add engagement fields
    comments?: number;   // Add engagement fields
    views?: number;      // Add engagement fields
  }>;
  onPostDeleted?: () => void; // Callback to refresh data after deletion
}

const getPlatformIcon = (platform: string) => {
  const platformLower = platform.toLowerCase();
  const iconClass = "w-5 h-5 rounded flex items-center justify-center text-xs font-bold text-white";
  
  switch (platformLower) {
    case 'twitter':
      return <div className={cn(iconClass, "bg-blue-500")}>𝕏</div>;
    case 'linkedin':
      return <div className={cn(iconClass, "bg-blue-600")}>in</div>;
    case 'tiktok':
      return <div className={cn(iconClass, "bg-pink-500")}>♪</div>;
    case 'facebook':
      return <div className={cn(iconClass, "bg-blue-700")}>f</div>;
    case 'instagram':
      return (
        <div className={cn(iconClass, "bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400")}>
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
          </svg>
        </div>
      );
    case 'youtube':
      return <div className={cn(iconClass, "bg-red-600")}>▶</div>;
    default:
      return <div className={cn(iconClass, "bg-gray-500")}>?</div>;
  }
};

export function ContentFeed({ posts = [], onPostDeleted }: ContentFeedProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const handleDelete = async (postId: string) => {
    if (!confirm('Are you sure you want to delete this post?')) {
      return;
    }

    console.log('Deleting post with ID:', postId);
    setDeletingId(postId);
    
    try {
      const { deletePost } = await import("@/lib/api");
      const result = await deletePost(postId);
      
      console.log('Delete successful:', result);

      // Call the callback to refresh the data
      if (onPostDeleted) {
        onPostDeleted();
      } else {
        console.warn('No onPostDeleted callback provided');
      }
    } catch (error) {
      console.error('Error deleting post:', error);
      alert(`Failed to delete post: ${error.message}`);
    } finally {
      setDeletingId(null);
    }
  };

  // Use posts if available, otherwise use mock data
  // Use posts if available, otherwise show empty state
  const displayData = posts.length > 0 ? posts.map(p => {
    // Calculate total engagement (likes + comments + views)
    const likes = p.likes || 0;
    const comments = p.comments || 0;
    const views = p.views || 0;
    
    // Format engagement display
    let engagementText = '';
    if (views > 0) {
      // If there are views, show views (common for videos)
      engagementText = views >= 1000 ? `${(views / 1000).toFixed(1)}K Views` : `${views} Views`;
    } else if (likes > 0) {
      // Otherwise show likes
      engagementText = likes >= 1000 ? `${(likes / 1000).toFixed(1)}K Likes` : `${likes} Likes`;
    } else if (comments > 0) {
      // Or show comments if no likes/views
      engagementText = `${comments} Comments`;
    } else {
      // If no engagement data at all
      engagementText = 'No engagement';
    }
    
    return {
      id: String(p.id),
      platform: p.platform,
      author: p.authorUsername,
      content: p.content,
      timestamp: new Date(p.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
      type: 'Post',
      engagement: engagementText,
      postUrl: p.postUrl // Add postUrl to the display data
    };
  }) : [];


  // Filter based on search
  // Filter and sort based on search relevance
const filteredData = displayData
  .filter(item => {
    // First, filter out items that don't match at all
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return item.content.toLowerCase().includes(query) || 
           item.author.toLowerCase().includes(query) ||
           item.platform.toLowerCase().includes(query);
  })
  .sort((a, b) => {
    // If no search query, keep original order (most recent first)
    if (!searchQuery) return 0;
    
    const query = searchQuery.toLowerCase();
    
    // Calculate relevance score for item 'a'
    let scoreA = 0;
    const contentA = a.content.toLowerCase();
    const authorA = a.author.toLowerCase();
    const platformA = a.platform.toLowerCase();
    
    // Content matches are most important (score: 100 points per match)
    const contentMatchesA = (contentA.match(new RegExp(query, 'g')) || []).length;
    scoreA += contentMatchesA * 100;
    
    // Author matches are medium importance (score: 50 points per match)
    const authorMatchesA = (authorA.match(new RegExp(query, 'g')) || []).length;
    scoreA += authorMatchesA * 50;
    
    // Platform matches are least important (score: 10 points per match)
    const platformMatchesA = (platformA.match(new RegExp(query, 'g')) || []).length;
    scoreA += platformMatchesA * 10;
    
    // Bonus: if match appears at the start of content (more relevant)
    if (contentA.startsWith(query)) scoreA += 200;
    if (authorA.startsWith(query)) scoreA += 100;
    
    // Calculate relevance score for item 'b' (same logic)
    let scoreB = 0;
    const contentB = b.content.toLowerCase();
    const authorB = b.author.toLowerCase();
    const platformB = b.platform.toLowerCase();
    
    const contentMatchesB = (contentB.match(new RegExp(query, 'g')) || []).length;
    scoreB += contentMatchesB * 100;
    
    const authorMatchesB = (authorB.match(new RegExp(query, 'g')) || []).length;
    scoreB += authorMatchesB * 50;
    
    const platformMatchesB = (platformB.match(new RegExp(query, 'g')) || []).length;
    scoreB += platformMatchesB * 10;
    
    if (contentB.startsWith(query)) scoreB += 200;
    if (authorB.startsWith(query)) scoreB += 100;
    
    // Sort by score (higher score = more relevant = appears first)
    return scoreB - scoreA;
  });

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base font-semibold">Recent Scraped Content</CardTitle>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search posts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-9 w-48 bg-gray-50 border-gray-200"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  <X className="h-4 w-4" />
                </button>
              )}
              {searchQuery && (
                <div className="absolute top-full mt-1 right-0 text-xs text-muted-foreground bg-white px-2 py-1 rounded border shadow-sm">
                  {filteredData.length} result{filteredData.length !== 1 ? 's' : ''}
                </div>
              )}
            </div>

            <Button variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="border-b border-gray-100">
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">S/N</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Platform</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Account Name</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Post Date</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Type</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Content Preview</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Engagement</th>
                <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Action</th>
              </tr>
            </thead>
            <tbody>
              {filteredData.length === 0 ? (
                <tr>
                  <td colSpan={8} className="text-center py-12">
                    <div className="flex flex-col items-center justify-center text-muted-foreground">
                      <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                        <Search className="h-8 w-8" />
                      </div>
                      <p className="text-lg font-medium mb-2">No Content Found</p>
                      <p className="text-sm max-w-md text-center">
                        {searchQuery 
                          ? `No posts match your search for "${searchQuery}". Try different keywords or clear your search.`
                          : "No scraped content available yet. Start scraping to see posts here."
                        }
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredData.map((item, index) => (
                  <tr key={item.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                    <td className="py-4 px-4 text-sm text-muted-foreground">{String(index + 1).padStart(2, '0')}</td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        {getPlatformIcon(item.platform)}
                        <span className="text-sm font-medium">{item.platform}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-sm text-foreground">{item.author}</td>
                    <td className="py-4 px-4 text-sm text-muted-foreground">{item.timestamp}</td>
                    <td className="py-4 px-4">
                      <span className="text-sm text-blue-600">{item.type}</span>
                    </td>
                    <td className="py-4 px-4">
                      <p className="text-sm text-foreground/80 line-clamp-1 max-w-xs">{item.content}</p>
                    </td>
                    <td className="py-4 px-4 text-sm text-muted-foreground">{item.engagement}</td>
                   <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0"
                          onClick={() => {
                            if (item.postUrl) {
                              window.open(item.postUrl, '_blank', 'noopener,noreferrer');
                            }
                          }}
                          disabled={!item.postUrl}
                          title={item.postUrl ? "View original post" : "No URL available"}
                        >
                          <ExternalLink className="h-4 w-4 text-muted-foreground" />
                        </Button>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="h-8 w-8 p-0 hover:text-red-600"
                          onClick={() => handleDelete(item.id)}
                          disabled={deletingId === item.id}
                          title="Delete post"
                        >
                          <Trash2 className="h-4 w-4 text-muted-foreground" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </CardContent>
    </Card>
  );
}
