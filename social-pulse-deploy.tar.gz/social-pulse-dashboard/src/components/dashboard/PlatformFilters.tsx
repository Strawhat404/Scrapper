import { useState } from "react";
import { cn } from "@/lib/utils";

interface Platform {
  id: string;
  name: string;
  icon: string;
  color: string;
  active: boolean;
}

const platforms: Platform[] = [
  { id: "facebook", name: "Facebook", icon: "f", color: "bg-platform-facebook", active: true },
  { id: "linkedin", name: "LinkedIn", icon: "in", color: "bg-platform-linkedin", active: true },
  { id: "tiktok", name: "TikTok", icon: "♪", color: "bg-platform-tiktok", active: true },
  { id: "instagram", name: "Instagram", icon: "svg", color: "bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400", active: false },
  { id: "twitter", name: "X", icon: "𝕏", color: "bg-platform-twitter", active: true },
  { id: "youtube", name: "YouTube", icon: "▶", color: "bg-platform-youtube", active: false },
];

export function PlatformFilters() {
  const [activePlatforms, setActivePlatforms] = useState<string[]>(
    platforms.filter(p => p.active).map(p => p.id)
  );

  const togglePlatform = (id: string) => {
    setActivePlatforms(prev => 
      prev.includes(id) 
        ? prev.filter(p => p !== id)
        : [...prev, id]
    );
  };

  return (
    <div className="space-y-3">
      <h3 className="px-3 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
        Platforms
      </h3>
      <div className="space-y-1">
        {platforms.map((platform) => {
          const isActive = activePlatforms.includes(platform.id);
          return (
            <button
              key={platform.id}
              onClick={() => togglePlatform(platform.id)}
              className={cn(
                "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all duration-200",
                isActive 
                  ? "bg-secondary text-foreground" 
                  : "text-muted-foreground hover:bg-secondary/50"
              )}
            >
              <div className={cn(
                "flex h-6 w-6 items-center justify-center rounded-md text-xs font-bold text-white",
                platform.color
              )}>
                {platform.icon === "svg" ? (
                  <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
                    <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                  </svg>
                ) : (
                  platform.icon
                )}
              </div>
              <span className="flex-1 text-left">{platform.name}</span>
              <div className={cn(
                "h-2 w-2 rounded-full transition-colors",
                isActive ? "bg-success" : "bg-muted"
              )} />
            </button>
          );
        })}
      </div>
    </div>
  );
}
