import { differenceInDays, format } from "date-fns";

// Calculate dynamic title for date ranges
export function calculateDateRangeTitle(startDate?: Date, endDate?: Date, totalDataDays?: number): string {
  if (startDate && endDate) {
    const days = differenceInDays(endDate, startDate) + 1; // +1 to include both start and end dates
    return `Content Volume (${days} Day${days !== 1 ? 's' : ''})`;
  }
  
  if (startDate && !endDate) {
    const days = differenceInDays(new Date(), startDate) + 1;
    return `Content Volume (${days} Day${days !== 1 ? 's' : ''} from ${format(startDate, 'MMM dd')})`;
  }
  
  if (!startDate && endDate) {
    // This case is less common, but we'll handle it
    return `Content Volume (up to ${format(endDate, 'MMM dd, yyyy')})`;
  }
  
  // No dates selected - use total available data
  if (totalDataDays && totalDataDays > 0) {
    return `Content Volume (${totalDataDays} Day${totalDataDays !== 1 ? 's' : ''} - All Data)`;
  }
  
  // Fallback to default
  return "Content Volume (Last 7 Days)";
}

// Calculate the number of days between two dates
export function getDaysBetween(startDate?: Date, endDate?: Date): number {
  if (!startDate || !endDate) return 7; // Default to 7 days
  return Math.max(1, differenceInDays(endDate, startDate) + 1);
}

// Format date range for display
export function formatDateRange(startDate?: Date, endDate?: Date): string {
  if (startDate && endDate) {
    return `${format(startDate, 'MMM dd')} - ${format(endDate, 'MMM dd, yyyy')}`;
  }
  
  if (startDate && !endDate) {
    return `From ${format(startDate, 'MMM dd, yyyy')}`;
  }
  
  if (!startDate && endDate) {
    return `Until ${format(endDate, 'MMM dd, yyyy')}`;
  }
  
  return "All time";
}

// Get the earliest and latest dates from scraped data
export function getDataDateRange(posts: Array<{ createdAt: string }>): { earliest?: Date; latest?: Date; totalDays?: number } {
  if (posts.length === 0) return {};
  
  const dates = posts.map(post => new Date(post.createdAt)).sort((a, b) => a.getTime() - b.getTime());
  const earliest = dates[0];
  const latest = dates[dates.length - 1];
  const totalDays = differenceInDays(latest, earliest) + 1;
  
  return { earliest, latest, totalDays };
}