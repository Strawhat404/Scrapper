// API service for communicating with the backend
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000';

// Type definitions for our data
export interface ScrapedPost {
  id: number;
  platform: 'YOUTUBE' | 'TWITTER' | 'TIKTOK' | 'INSTAGRAM' | 'FACEBOOK';
  postId: string;
  authorUsername: string;
  authorName: string;
  content: string;
  postUrl: string;
  likes: number;
  comments: number;
  views: number;
  mediaType: 'IMAGE' | 'VIDEO' | 'TEXT';
  mediaUrls: string[];
  thumbnailUrl: string;
  createdAt: string;
}

// Scrape Instagram by URL
export async function scrapeInstagram(url: string): Promise<ScrapedPost | null> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/instagram?url=${encodeURIComponent(url)}`);
    if (!response.ok) throw new Error('Failed to scrape Instagram');
    return await response.json();
  } catch (error) {
    console.error('Error scraping Instagram:', error);
    return null;
  }
}

// Scrape YouTube by keyword
export async function scrapeYouTube(keyword: string): Promise<ScrapedPost[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/youtube?q=${encodeURIComponent(keyword)}`);
    if (!response.ok) throw new Error('Failed to scrape YouTube');
    return await response.json();
  } catch (error) {
    console.error('Error scraping YouTube:', error);
    return [];
  }
}

// Scrape Twitter by keyword
export async function scrapeTwitter(keyword: string): Promise<ScrapedPost[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/twitter?q=${encodeURIComponent(keyword)}`);
    if (!response.ok) throw new Error('Failed to scrape Twitter');
    return await response.json();
  } catch (error) {
    console.error('Error scraping Twitter:', error);
    return [];
  }
}

// Scrape TikTok by hashtag
export async function scrapeTikTok(hashtag: string): Promise<ScrapedPost[]> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/tiktok?q=${encodeURIComponent(hashtag)}`);
    if (!response.ok) throw new Error('Failed to scrape TikTok');
    return await response.json();
  } catch (error) {
    console.error('Error scraping TikTok:', error);
    return [];
  }
}

// Scrape multiple platforms at once
export async function scrapeMultiplePlatforms(
  query: string,
  platforms: string[]
): Promise<{ platform: string; data: ScrapedPost[] }[]> {

  // Create an array of promises for concurrent execution
  const scrapePromises = platforms.map(async (platform) => {
    let data: ScrapedPost[] = [];

    switch (platform) {
      case 'youtube':
        data = await scrapeYouTube(query);
        break;
      case 'twitter':
        data = await scrapeTwitter(query);
        break;
      case 'tiktok':
        data = await scrapeTikTok(query);
        break;
      case 'instagram':
        // Instagram needs URL, but we'll return empty for now to match interface
        // Real implementation would need a separate URL input
        break;
    }
    return { platform, data };
  });

  // Wait for all scrapes to finish in parallel
  const results = await Promise.all(scrapePromises);
  return results;
}

// Get all scraped posts from database
export async function getAllPosts(
  limit?: number, 
  platform?: string,
  startDate?: Date,
  endDate?: Date,
  countries?: string[]
): Promise<ScrapedPost[]> {
  try {
    let url = `${API_BASE_URL}/test/posts`;
    const params = new URLSearchParams();

    if (limit) params.append('limit', limit.toString());
    if (platform) params.append('platform', platform);
    if (startDate) params.append('startDate', startDate.toISOString());
    if (endDate) params.append('endDate', endDate.toISOString());
    if (countries && countries.length > 0) {
      countries.forEach(country => params.append('countries', country));
    }

    if (params.toString()) url += `?${params.toString()}`;

    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch posts');

    const data = await response.json();
    return data.posts || [];
  } catch (error) {
    console.error('Error fetching posts:', error);
    return [];
  }
}

// Get statistics from database
export async function getStats(): Promise<{ 
  totalPosts: number; 
  byPlatform: Array<{ 
    platform: string; 
    totalCount: string;
    todayCount: string;
    lastCrawl: string;
  }> 
}> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/stats`);
    if (!response.ok) throw new Error('Failed to fetch stats');
    return await response.json();
  } catch (error) {
    console.error('Error fetching stats:', error);
    return { totalPosts: 0, byPlatform: [] };
  }
}

// Get dashboard stats
export async function getDashboardStats() {
  try {
    const response = await fetch(`${API_BASE_URL}/test/dashboard/stats`);
    if (!response.ok) {
      console.error('Dashboard stats API error:', response.status, response.statusText);
      throw new Error('Failed to fetch dashboard stats');
    }
    const data = await response.json();
    console.log('Dashboard stats received:', data);
    console.log('postsTodayChange:', data.postsTodayChange);
    console.log('activeCrawlsChange:', data.activeCrawlsChange);
    console.log('processingQueueChange:', data.processingQueueChange);
    console.log('successRateChange:', data.successRateChange);
    return data;
  } catch (error) {
    console.error('Error fetching dashboard stats:', error);
    return {
      totalPosts: 0,
      postsToday: 0,
      postsTodayChange: 0,
      activeCrawls: 0,
      activeCrawlsChange: 0,
      processingQueue: 0,
      processingQueueChange: 0,
      successRate: 0,
      successRateChange: 0,
      byPlatform: [],
    };
  }
}

// Get volume chart data
export async function getVolumeData(days: number = 7, countries?: string[]) {
  try {
    const params = new URLSearchParams();
    params.append('days', days.toString());
    if (countries && countries.length > 0) {
      countries.forEach(country => params.append('countries', country));
    }

    const response = await fetch(`${API_BASE_URL}/test/dashboard/volume?${params.toString()}`);
    if (!response.ok) throw new Error('Failed to fetch volume data');
    return await response.json();
  } catch (error) {
    console.error('Error fetching volume data:', error);
    return [];
  }
}

// Delete a post by ID
export async function deletePost(postId: string): Promise<{ success: boolean; message: string }> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/posts/${postId}`, {
      method: 'DELETE',
    });
    
    const data = await response.json();
    
    if (!response.ok) {
      throw new Error(data.message || 'Failed to delete post');
    }
    
    return data;
  } catch (error) {
    console.error('Error deleting post:', error);
    throw error;
  }
}
// Export posts to CSV
export async function exportPosts(
  format: 'csv' | 'json' = 'csv',
  filters?: {
    platform?: string;
    startDate?: Date;
    endDate?: Date;
    countries?: string[];
    searchQuery?: string;
  }
): Promise<Blob> {
  try {
    const params = new URLSearchParams();
    params.append('format', format);
    
    if (filters?.platform) params.append('platform', filters.platform);
    if (filters?.startDate) params.append('startDate', filters.startDate.toISOString());
    if (filters?.endDate) params.append('endDate', filters.endDate.toISOString());
    if (filters?.searchQuery) params.append('search', filters.searchQuery);
    if (filters?.countries && filters.countries.length > 0) {
      filters.countries.forEach(country => params.append('countries', country));
    }

    const response = await fetch(`${API_BASE_URL}/test/export?${params.toString()}`);
    if (!response.ok) throw new Error('Failed to export data');
    
    return await response.blob();
  } catch (error) {
    console.error('Error exporting data:', error);
    throw error;
  }
}

// Get pipeline statistics
export async function getPipelineStats(): Promise<{
  running: number;
  queued: number;
  completed: number;
  failed: number;
  jobs: Array<{
    id: string;
    type: string;
    status: 'running' | 'completed' | 'queued' | 'failed';
    platform: string;
    timestamp: string;
    progress?: number;
  }>;
}> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/pipeline/stats`);
    if (!response.ok) throw new Error('Failed to fetch pipeline stats');
    return await response.json();
  } catch (error) {
    console.error('Error fetching pipeline stats:', error);
    return {
      running: 0,
      queued: 0,
      completed: 0,
      failed: 0,
      jobs: []
    };
  }
}

// Get recent pipeline activity
export async function getPipelineActivity(limit: number = 10): Promise<Array<{
  id: string;
  action: string;
  platform: string;
  status: 'success' | 'error' | 'info';
  timestamp: string;
  message: string;
}>> {
  try {
    const response = await fetch(`${API_BASE_URL}/test/pipeline/activity?limit=${limit}`);
    if (!response.ok) throw new Error('Failed to fetch pipeline activity');
    const data = await response.json();
    return data.activities || [];
  } catch (error) {
    console.error('Error fetching pipeline activity:', error);
    return [];
  }
}