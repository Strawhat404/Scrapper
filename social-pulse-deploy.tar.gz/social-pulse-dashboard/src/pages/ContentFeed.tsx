import { Search, Filter, ExternalLink, Calendar, X, Download, RefreshCw, Plus, Trash2, Globe } from "lucide-react";
import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { CountrySelect } from "@/components/ui/country-select";
import { cn } from "@/lib/utils";
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getAllPosts, ScrapedPost, exportPosts } from "@/lib/api";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

interface ContentItem {
  id: string;
  platform: string;
  author: string;
  content: string;
  timestamp: string;
  type: string;
  engagement: string;
  postUrl?: string; // Add postUrl field
}

const getPlatformIcon = (platform: string) => {
  const platformLower = platform.toLowerCase();
  const iconClass = "w-5 h-5 rounded flex items-center justify-center text-xs font-bold text-white";
  
  switch (platformLower) {
    case 'twitter':
      return <div className={cn(iconClass, "bg-blue-500")}>𝕏</div>;
    case 'linkedin':
      return <div className={cn(iconClass, "bg-blue-600")}>in</div>;
    case 'tiktok':
      return <div className={cn(iconClass, "bg-pink-500")}>♪</div>;
    case 'facebook':
      return <div className={cn(iconClass, "bg-blue-700")}>f</div>;
    case 'instagram':
      return (
        <div className={cn(iconClass, "bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400")}>
          <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
            <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
          </svg>
        </div>
      );
    case 'youtube':
      return <div className={cn(iconClass, "bg-red-600")}>▶</div>;
    default:
      return <div className={cn(iconClass, "bg-gray-500")}>?</div>;
  }
};

const ContentFeed = () => {
  const navigate = useNavigate();
  const [posts, setPosts] = useState<ScrapedPost[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedPlatform, setSelectedPlatform] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [itemToDelete, setItemToDelete] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    async function loadPosts() {
      setLoading(true);
      const data = await getAllPosts(
        100, 
        selectedPlatform === "all" ? undefined : selectedPlatform,
        startDate,
        endDate,
        selectedCountries.length > 0 ? selectedCountries : undefined
      );
      setPosts(data);
      setLoading(false);
    }
    loadPosts();
  }, [selectedPlatform, startDate, endDate, selectedCountries]);

  // Refresh handler - reload posts
  const handleRefresh = async () => {
    setLoading(true);
    const data = await getAllPosts(
      100, 
      selectedPlatform === "all" ? undefined : selectedPlatform,
      startDate,
      endDate,
      selectedCountries.length > 0 ? selectedCountries : undefined
    );
    setPosts(data);
    setLoading(false);
  };

  // New Analysis handler - navigate to Discovery page
  const handleNewAnalysis = () => {
    navigate('/discovery');
  };

  const [clearDialogOpen, setClearDialogOpen] = useState(false);

  const handleClearClick = () => {
    setClearDialogOpen(true);
  };

  const handleClearConfirm = () => {
    setStartDate(undefined);
    setEndDate(undefined);
    setSelectedCountries([]);
    setSelectedPlatform("all");
    setSelectedStatus("all");
    setSearchQuery("");
    setClearDialogOpen(false);
  };

  const handleDeleteClick = (itemId: string) => {
    setItemToDelete(itemId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = async () => {
    if (!itemToDelete) return;
    
    try {
      const { deletePost } = await import("@/lib/api");
      await deletePost(itemToDelete);
      
      // Refresh the posts list
      const data = await getAllPosts(
        100, 
        selectedPlatform === "all" ? undefined : selectedPlatform,
        startDate,
        endDate,
        selectedCountries.length > 0 ? selectedCountries : undefined
      );
      setPosts(data);
      
      setDeleteDialogOpen(false);
      setItemToDelete(null);
    } catch (error) {
      console.error('Error deleting post:', error);
      alert('Failed to delete post. Please try again.');
    }
  };

  const handleExport = async () => {
    setIsExporting(true);
    try {
      const blob = await exportPosts('csv', {
        platform: selectedPlatform === "all" ? undefined : selectedPlatform,
        startDate,
        endDate,
        countries: selectedCountries.length > 0 ? selectedCountries : undefined,
        searchQuery: searchQuery || undefined
      });

      // Create download link
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `social-pulse-export-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting data:', error);
      alert('Failed to export data. Please try again.');
    } finally {
      setIsExporting(false);
    }
  };

  // Use real posts data only, no fallback to mock data
  const displayData = posts.length > 0 ? posts.map(p => ({
    id: String(p.id),
    platform: p.platform,
    author: p.authorUsername,
    content: p.content,
    timestamp: new Date(p.createdAt).toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }),
    type: p.mediaType === 'VIDEO' ? 'Video' : p.mediaType === 'IMAGE' ? 'Post' : 'Article',
    engagement: `${p.likes} Likes`,
    postUrl: p.postUrl // Add postUrl here
  })) : [];

  // Filter data
  const filteredData = displayData.filter(item => {
    const matchesSearch = !searchQuery || 
      item.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesPlatform = selectedPlatform === "all" || item.platform.toLowerCase() === selectedPlatform.toLowerCase();
    return matchesSearch && matchesPlatform;
  });

  return (
    <Layout hideHeader>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold text-foreground">Content Feed</h1>
            <p className="text-sm text-muted-foreground">View and manage all scraped social media content</p>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleRefresh} disabled={loading}>
              <RefreshCw className={cn("h-4 w-4 mr-2", loading && "animate-spin")} />
              Refresh
            </Button>
            <Button size="sm" className="bg-blue-600 hover:bg-blue-700" onClick={handleNewAnalysis}>
              <Plus className="h-4 w-4 mr-2" />
              New Analysis
            </Button>
          </div>
        </div>

        {/* Search Bar - Date, End Date, Countries, Clear Data */}
        <div className="flex gap-4 items-center bg-white p-4 rounded-lg border">
          {/* Start Date */}
          <div className="flex flex-col gap-1 flex-1">
            <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              Start Date
            </label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal h-10 border-gray-200"
                >
                  {startDate ? format(startDate, "MMM dd, yyyy") : "Select start date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={startDate}
                  onSelect={setStartDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* End Date */}
          <div className="flex flex-col gap-1 flex-1">
            <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
              <Calendar className="h-3 w-3" />
              End Date
            </label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal h-10 border-gray-200"
                >
                  {endDate ? format(endDate, "MMM dd, yyyy") : "Select end date"}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={endDate}
                  onSelect={setEndDate}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Target Countries - CountrySelect */}
          <div className="flex flex-col gap-1 flex-1">
            <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
              <Globe className="h-3 w-3" />
              Target Countries
            </label>
            <CountrySelect
              value={selectedCountries}
              onChange={setSelectedCountries}
              placeholder="Select countries..."
              multiple={true}
            />
          </div>

          {/* Clear Data Button */}
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={handleClearClick}
            className="text-red-500 hover:text-red-600 hover:bg-red-50 h-10 mt-5 flex-shrink-0"
          >
            <X className="mr-1 h-4 w-4" />
            Clear Data
          </Button>
        </div>

        {/* Clear Data Confirmation Dialog */}
        <Dialog open={clearDialogOpen} onOpenChange={setClearDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Are you sure?</DialogTitle>
              <DialogDescription>
                This action cannot be undone. This will permanently delete the scraped data from your dashboard.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="flex gap-2 sm:gap-2">
              <Button variant="outline" onClick={() => setClearDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleClearConfirm}>
                Delete Data
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>

        {/* Platform and Status Filters Row */}
        <div className="flex gap-4 items-center justify-between">
          <div className="flex gap-2">
            {/* Platform Filter */}
            <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
              <SelectTrigger className="w-[140px] h-9 bg-white">
                <SelectValue placeholder="All Platforms" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Platforms</SelectItem>
                <SelectItem value="twitter">Twitter</SelectItem>
                <SelectItem value="linkedin">LinkedIn</SelectItem>
                <SelectItem value="tiktok">TikTok</SelectItem>
                <SelectItem value="facebook">Facebook</SelectItem>
                <SelectItem value="instagram">Instagram</SelectItem>
                <SelectItem value="youtube">YouTube</SelectItem>
              </SelectContent>
            </Select>

            {/* Status Filter */}
            <Select value={selectedStatus} onValueChange={setSelectedStatus}>
              <SelectTrigger className="w-[120px] h-9 bg-white">
                <SelectValue placeholder="All Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="processed">Processed</SelectItem>
                <SelectItem value="processing">Processing</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* More Filters Button */}
          <Button variant="outline" size="sm" className="text-muted-foreground">
            <Filter className="h-4 w-4 mr-2" />
            More Filters
          </Button>
        </div>

        {/* Content Table Card */}
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-base font-semibold">All Scraped Content</CardTitle>
              <div className="flex items-center gap-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search posts..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 h-9 w-48 bg-gray-50 border-gray-200"
                  />
                </div>
                <Button variant="outline" size="sm" onClick={handleExport} disabled={isExporting}>
                  <Download className="h-4 w-4 mr-2" />
                  {isExporting ? "Exporting..." : "Export"}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">S/N</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Platform</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Account Name</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Post Date</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Type</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Content Preview</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Engagement</th>
                    <th className="text-left py-3 px-4 text-xs font-medium text-muted-foreground uppercase tracking-wider">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {loading ? (
                    <tr>
                      <td colSpan={8} className="text-center py-12">
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <RefreshCw className="h-8 w-8 animate-spin mb-4" />
                          <p className="text-lg font-medium">Loading content...</p>
                        </div>
                      </td>
                    </tr>
                  ) : filteredData.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="text-center py-12">
                        <div className="flex flex-col items-center justify-center text-muted-foreground">
                          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center mb-4">
                            <Search className="h-8 w-8" />
                          </div>
                          <p className="text-lg font-medium mb-2">No Content Found</p>
                          <p className="text-sm max-w-md text-center">
                            {searchQuery 
                              ? `No posts match your search for "${searchQuery}". Try different keywords or clear your search.`
                              : "No scraped content available yet. Start scraping to see posts here."
                            }
                          </p>
                        </div>
                      </td>
                    </tr>
                  ) : (
                    filteredData.map((item, index) => (
                      <tr key={item.id} className="border-b border-gray-50 hover:bg-gray-50/50">
                        <td className="py-4 px-4 text-sm text-muted-foreground">{String(index + 1).padStart(2, '0')}</td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-2">
                            {getPlatformIcon(item.platform)}
                            <span className="text-sm font-medium">{item.platform}</span>
                          </div>
                        </td>
                        <td className="py-4 px-4 text-sm text-foreground">{item.author}</td>
                        <td className="py-4 px-4 text-sm text-muted-foreground">{item.timestamp}</td>
                        <td className="py-4 px-4">
                          <span className="text-sm text-blue-600">{item.type}</span>
                        </td>
                        <td className="py-4 px-4">
                          <p className="text-sm text-foreground/80 line-clamp-1 max-w-xs">{item.content}</p>
                        </td>
                        <td className="py-4 px-4 text-sm text-muted-foreground">{item.engagement}</td>
                        <td className="py-4 px-4">
                          <div className="flex items-center gap-1">
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0"
                              onClick={() => {
                                if (item.postUrl) {
                                  window.open(item.postUrl, '_blank', 'noopener,noreferrer');
                                }
                              }}
                              disabled={!item.postUrl}
                              title={item.postUrl ? "View original post" : "No URL available"}
                            >
                              <ExternalLink className="h-4 w-4 text-muted-foreground" />
                            </Button>
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="h-8 w-8 p-0 hover:bg-red-50"
                              onClick={() => handleDeleteClick(item.id)}
                            >
                              <Trash2 className="h-4 w-4 text-muted-foreground hover:text-red-500" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>

        {/* Delete Confirmation Dialog */}
        <Dialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Are you sure?</DialogTitle>
              <DialogDescription>
                This action cannot be undone. This will permanently delete the scraped data from your dashboard.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="flex gap-2 sm:gap-2">
              <Button variant="outline" onClick={() => setDeleteDialogOpen(false)}>
                Cancel
              </Button>
              <Button variant="destructive" onClick={handleDeleteConfirm}>
                Delete Data
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </Layout>
  );
};

export default ContentFeed;
