import { useState, useEffect } from "react";
import { Search, Play, Settings, Calendar, Filter, X, Plus, Globe } from "lucide-react";
import { Layout } from "@/components/Layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { CountrySelect } from "@/components/ui/country-select";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { scrapeMultiplePlatforms } from "@/lib/api";
import { ContentFeed } from "@/components/dashboard/ContentFeed";


interface Platform {
  id: string;
  name: string;
  icon: string;
  color: string;
  enabled: boolean;
}

const platforms: Platform[] = [
  { id: "facebook", name: "Facebook", icon: "f", color: "bg-blue-700", enabled: true },
  { id: "linkedin", name: "LinkedIn", icon: "in", color: "bg-blue-600", enabled: true },
  { id: "tiktok", name: "TikTok", icon: "♪", color: "bg-pink-500", enabled: true },
  { id: "instagram", name: "Instagram", icon: "svg", color: "bg-gradient-to-br from-purple-500 via-pink-500 to-orange-400", enabled: true },
  { id: "twitter", name: "X (Twitter)", icon: "𝕏", color: "bg-blue-500", enabled: true },
  { id: "youtube", name: "YouTube", icon: "▶", color: "bg-red-600", enabled: true },
];

const Discovery = () => {
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(platforms.map(p => p.id));
  const [searchQuery, setSearchQuery] = useState("");
  const [keywords, setKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState("");
  const [targetLinks, setTargetLinks] = useState("");
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const [isStarting, setIsStarting] = useState(false);
  const [scrapedResults, setScrapedResults] = useState<any[]>([]);

  // Load posts based on selected filters (automatically updates when dates change)
  useEffect(() => {
    loadPosts();
  }, [startDate, endDate]); // Re-run when dates change

  async function loadPosts() {
    const { getAllPosts } = await import("@/lib/api");
    const posts = await getAllPosts(50, undefined, startDate, endDate);
    if (posts && posts.length > 0) {
      setScrapedResults(posts);
    } else {
      setScrapedResults([]);
    }
  }

  const handlePlatformToggle = (platformId: string) => {
    setSelectedPlatforms(prev =>
      prev.includes(platformId)
        ? prev.filter(id => id !== platformId)
        : [...prev, platformId]
    );
  };

  const addKeyword = () => {
    if (newKeyword.trim() && !keywords.includes(newKeyword.trim())) {
      setKeywords(prev => [...prev, newKeyword.trim()]);
      setNewKeyword("");
    }
  };

  const removeKeyword = (keyword: string) => {
    setKeywords(prev => prev.filter(k => k !== keyword));
  };

  const handleKeywordKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      addKeyword();
    }
  };

  const handleStartScraping = async () => {
    setIsStarting(true);

    try {
      // Use keywords joined as search query
      const query = keywords.join(' ');
      
      // Import the API function at the top of the file first
      const { scrapeMultiplePlatforms } = await import("@/lib/api");

      // Call the real API
      const results = await scrapeMultiplePlatforms(query, selectedPlatforms);

      console.log("Scraping results:", results);

      // Flatten the results from multiple platforms into one list
      const allPosts = results.flatMap(r => r.data).map(post => ({
        ...post,
        id: String(post.id) // Ensure ID is a string for the component
      }));

      if (allPosts.length > 0) {
        setScrapedResults(allPosts);
      } else {
        alert("Scraping finished but no posts were found.");
      }

    } catch (error) {
      console.error("Error starting scraping:", error);
      alert("Failed to start scraping. Check console for details.");
    } finally {
      setIsStarting(false);
    }
  };


  return (
    <Layout hideHeader>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Content Discovery</h1>
          <p className="text-muted-foreground">Start new scraping jobs across social platforms</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Search Configuration */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="h-5 w-5" />
                Search Configuration
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Keywords & Hashtags */}
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Keywords & Hashtags
                </label>
                <div className="space-y-3">
                  <div className="flex flex-wrap gap-2 min-h-[40px] p-3 border rounded-lg bg-muted/20">
                    {keywords.map((keyword, index) => (
                      <Badge key={index} variant="secondary" className="bg-blue-50 text-blue-600 hover:bg-blue-100">
                        {keyword}
                        <button
                          onClick={() => removeKeyword(keyword)}
                          className="ml-1 hover:text-blue-800"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </Badge>
                    ))}
                    <div className="flex gap-2 items-center flex-1 min-w-[200px]">
                      <Input
                        placeholder="Add keywords or hashtags..."
                        value={newKeyword}
                        onChange={(e) => setNewKeyword(e.target.value)}
                        onKeyPress={handleKeywordKeyPress}
                        className="border-none bg-transparent p-0 h-6 text-sm flex-1 focus-visible:ring-0"
                      />
                      {newKeyword.trim() && (
                        <Button
                          type="button"
                          size="sm"
                          onClick={addKeyword}
                          className="h-6 px-2 text-xs"
                        >
                          <Plus className="h-3 w-3 mr-1" />
                          Add
                        </Button>
                      )}
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Enter multiple keywords or hashtags to broaden your search. Press Enter or click Add to include each one.
                  </p>
                </div>
              </div>

              {/* Target Specific Links */}
              <div>
                <label className="text-sm font-medium text-foreground mb-2 block">
                  Target Specific Links (Optional)
                </label>
                <Textarea
                  placeholder="Paste Facebook Group or page URLs..."
                  value={targetLinks}
                  onChange={(e) => setTargetLinks(e.target.value)}
                  className="min-h-[80px] resize-none"
                />
              </div>

              {/* Date and Country Filters */}
              <div className="flex gap-4 items-end">
                {/* Start Date */}
                <div className="flex flex-col gap-1 flex-1">
                  <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    Start Date
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal h-9"
                      >
                        <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
                        {startDate ? format(startDate, "MMM dd, yyyy") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={startDate}
                        onSelect={setStartDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* End Date */}
                <div className="flex flex-col gap-1 flex-1">
                  <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                    <Calendar className="h-3 w-3" />
                    End Date
                  </label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        className="w-full justify-start text-left font-normal h-9"
                      >
                        <Calendar className="mr-2 h-4 w-4 text-muted-foreground" />
                        {endDate ? format(endDate, "MMM dd, yyyy") : "Select date"}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <CalendarComponent
                        mode="single"
                        selected={endDate}
                        onSelect={setEndDate}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>

                {/* Clear Dates Button */}
                {(startDate || endDate) && (
                  <div className="flex items-end">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        setStartDate(undefined);
                        setEndDate(undefined);
                      }}
                      className="h-9"
                    >
                      <X className="h-4 w-4 mr-1" />
                      Clear
                    </Button>
                  </div>
                )}

                {/* Target Countries - CountrySelect */}
                <div className="flex flex-col gap-1 flex-1">
                  <label className="text-xs text-muted-foreground font-medium flex items-center gap-1">
                    <Globe className="h-3 w-3" />
                    Target Countries
                  </label>
                  <CountrySelect
                    value={selectedCountries}
                    onChange={setSelectedCountries}
                    placeholder="Select countries..."
                    multiple={true}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Platform Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Platform Selection
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {platforms.map((platform) => (
                  <div
                    key={platform.id}
                    className={cn(
                      "flex items-center gap-3 p-4 rounded-lg border transition-all cursor-pointer",
                      selectedPlatforms.includes(platform.id)
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    )}
                    onClick={() => handlePlatformToggle(platform.id)}
                  >
                    <Checkbox
                      checked={selectedPlatforms.includes(platform.id)}
                      onChange={() => handlePlatformToggle(platform.id)}
                    />
                    <div className={cn(
                      "flex h-10 w-10 items-center justify-center rounded-lg text-sm font-bold text-white",
                      platform.color
                    )}>
                      {platform.icon === "svg" ? (
                        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                        </svg>
                      ) : (
                        platform.icon
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground">{platform.name}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Scraping Controls */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Start Scraping</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Platforms:</span>
                  <span className="font-medium">{selectedPlatforms.length} selected</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Keywords:</span>
                  <span className="font-medium">{keywords.length > 0 ? "✓" : "Required"}</span>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button
                  onClick={handleStartScraping}
                  disabled={keywords.length === 0 || selectedPlatforms.length === 0 || isStarting}
                  className="w-full h-11 gap-2"
                >
                  <Play className="h-4 w-4" />
                  {isStarting ? "Starting..." : "Start Scraping"}
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Selected Platforms</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {selectedPlatforms.length === 0 ? (
                  <p className="text-sm text-muted-foreground">No platforms selected</p>
                ) : (
                  selectedPlatforms.map(platformId => {
                    const platform = platforms.find(p => p.id === platformId);
                    return platform ? (
                      <div key={platform.id} className="flex items-center gap-2">
                        <div className={cn(
                          "flex h-6 w-6 items-center justify-center rounded text-xs font-bold text-white",
                          platform.color
                        )}>
                          {platform.icon === "svg" ? (
                            <svg viewBox="0 0 24 24" fill="currentColor" className="w-3 h-3">
                              <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                            </svg>
                          ) : (
                            platform.icon
                          )}
                        </div>
                        <span className="text-sm text-foreground">{platform.name}</span>
                      </div>
                    ) : null;
                  })
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Results Section - Shows up when we have content */}
      {scrapedResults.length > 0 && (
        <div className="mt-8">
          <h2 className="text-lg font-semibold mb-4 px-1">
            {isStarting ? "Scraping in progress..." : "Recent Scraped Content"}
          </h2>
          <ContentFeed posts={scrapedResults} onPostDeleted={loadPosts} />
        </div>
      )}
    </Layout>
  );
};

export default Discovery;