import { Database, TrendingUp, Users, Clock } from "lucide-react";
import { Layout } from "@/components/Layout";
import { SearchBar } from "@/components/dashboard/SearchBar";
import { StatsCard } from "@/components/dashboard/StatsCard";
import { VolumeChart } from "@/components/dashboard/VolumeChart";
import { PlatformStatus } from "@/components/dashboard/PlatformStatus";
import { ContentFeed } from "@/components/dashboard/ContentFeed";
import { useEffect, useState } from "react";
import { getAllPosts, getDashboardStats, getVolumeData } from "@/lib/api";
import { getDataDateRange, getDaysBetween } from "@/lib/date-utils";

const Index = () => {
  // State for dashboard statistics
  const [stats, setStats] = useState({
    totalPosts: 0,
    postsToday: 0,
    postsTodayChange: 0,
    activeCrawls: 0,
    activeCrawlsChange: 0,
    processingQueue: 0,
    processingQueueChange: 0,
    successRate: 0,
    successRateChange: 0,
  });
  
  // State for volume chart data
  const [volumeData, setVolumeData] = useState([]);
  
  // State for recent posts
  const [recentPosts, setRecentPosts] = useState([]);
  
  // State for filters
  const [startDate, setStartDate] = useState<Date>();
  const [endDate, setEndDate] = useState<Date>();
  const [countries, setCountries] = useState<string[]>([]);
  
  // Loading state
  const [loading, setLoading] = useState(true);

  // Fetch all data when component mounts or filters change
  useEffect(() => {
    loadData();
  }, [startDate, endDate, countries]); // Re-run when filters change

  async function loadData() {
    setLoading(true);
    
    // Calculate days for volume chart based on date range
    const days = getDaysBetween(startDate, endDate);
    
    // Fetch all three data sources in parallel (faster!)
    const [dashboardStats, volume, posts] = await Promise.all([
      getDashboardStats(),  // Dashboard stats (not filtered by date/country yet)
      getVolumeData(days, countries.length > 0 ? countries : undefined),
      getAllPosts(10, undefined, startDate, endDate, countries.length > 0 ? countries : undefined)
    ]);
    
    // Update all state variables
    setStats(dashboardStats);
    setVolumeData(volume);
    setRecentPosts(posts);
    
    setLoading(false);
  }

  // Calculate total data days for dynamic title
  const { totalDays } = getDataDateRange(recentPosts);

  // Handle filter changes
  const handleStartDateChange = (date: Date | undefined) => {
    setStartDate(date);
  };

  const handleEndDateChange = (date: Date | undefined) => {
    setEndDate(date);
  };

  const handleCountriesChange = (newCountries: string[]) => {
    setCountries(newCountries);
  };

  const handleClearFilters = () => {
    setStartDate(undefined);
    setEndDate(undefined);
    setCountries([]);
  };

  return (
    <Layout>
      {/* Search Bar with dynamic filters */}
      <SearchBar 
        startDate={startDate}
        endDate={endDate}
        countries={countries}
        onStartDateChange={handleStartDateChange}
        onEndDateChange={handleEndDateChange}
        onCountriesChange={handleCountriesChange}
        onClear={handleClearFilters}
      />

      {/* Stats Grid - NOW WITH REAL DATA */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatsCard
          title="Total Posts Scraped"
          value={loading ? "..." : stats.totalPosts.toLocaleString()}
          change={`${stats.postsTodayChange >= 0 ? '+' : ''}${stats.postsTodayChange}`}
          changeType={stats.postsTodayChange >= 0 ? "positive" : "negative"}
          icon={Database}
          iconColor="text-primary"
        />
        <StatsCard
          title="Active Crawls"
          value={loading ? "..." : stats.activeCrawls.toString()}
          change={`${stats.activeCrawlsChange >= 0 ? '+' : ''}${stats.activeCrawlsChange}`}
          changeType={stats.activeCrawlsChange >= 0 ? "positive" : "negative"}
          icon={TrendingUp}
          iconColor="text-blue-500"
        />
        <StatsCard
          title="Processing Queue"
          value={loading ? "..." : stats.processingQueue.toString()}
          change={`${stats.processingQueueChange >= 0 ? '+' : ''}${stats.processingQueueChange}`}
          changeType={stats.processingQueueChange <= 0 ? "positive" : "negative"}
          icon={Clock}
          iconColor="text-yellow-500"
        />
        <StatsCard
          title="Success Rate"
          value={loading ? "..." : `${stats.successRate}%`}
          change={`${stats.successRateChange >= 0 ? '+' : ''}${stats.successRateChange}%`}
          changeType={stats.successRateChange >= 0 ? "positive" : "negative"}
          icon={Users}
          iconColor="text-green-500"
        />
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Volume Chart - NOW RECEIVES REAL DATA WITH DYNAMIC TITLE */}
        <VolumeChart 
          data={volumeData} 
          startDate={startDate}
          endDate={endDate}
          totalDataDays={totalDays}
          countries={countries}
        />

        {/* Platform Status */}
        <PlatformStatus />
      </div>

      {/* Content Feed - Full Width */}
      <ContentFeed posts={recentPosts} onPostDeleted={loadData} />
    </Layout>
  );
};

export default Index;
