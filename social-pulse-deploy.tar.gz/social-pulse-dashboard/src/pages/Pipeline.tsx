import { Layout } from "@/components/Layout";
import { PipelineStatus } from "@/components/dashboard/PipelineStatus";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, Clock, CheckCircle2, AlertCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { getPipelineStats } from "@/lib/api";

const Pipeline = () => {
  const [stats, setStats] = useState({
    running: 0,
    queued: 0,
    completed: 0,
    failed: 0
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPipelineData();
    
    // Set up auto-refresh every 30 seconds
    const interval = setInterval(loadPipelineData, 30000);
    return () => clearInterval(interval);
  }, []);

  async function loadPipelineData() {
    try {
      const pipelineStats = await getPipelineStats();
      
      setStats({
        running: pipelineStats.running,
        queued: pipelineStats.queued,
        completed: pipelineStats.completed,
        failed: pipelineStats.failed
      });
    } catch (error) {
      console.error('Error loading pipeline data:', error);
      // If API fails, show zeros instead of mock data
      setStats({ running: 0, queued: 0, completed: 0, failed: 0 });
    } finally {
      setLoading(false);
    }
  }

  const statsConfig = [
    { label: "Running", value: stats.running, icon: Activity, color: "text-blue-600" },
    { label: "Queued", value: stats.queued, icon: Clock, color: "text-yellow-600" },
    { label: "Completed", value: stats.completed, icon: CheckCircle2, color: "text-green-600" },
    { label: "Failed", value: stats.failed, icon: AlertCircle, color: "text-red-600" },
  ];

  return (
    <Layout hideHeader>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Pipeline Status</h1>
          <p className="text-muted-foreground">Monitor scraping jobs and processing queue</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {statsConfig.map((stat) => (
          <Card key={stat.label}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                  <p className="text-2xl font-bold text-foreground mt-1">
                    {loading ? "..." : stat.value}
                  </p>
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pipeline Queue - Full Width */}
      <div className="w-full">
        <PipelineStatus />
      </div>
    </Layout>
  );
};

export default Pipeline;
